export class Product {
  constructor(public id: string,
              public titre: string,
              public auteur: string,
              public genre: string,
              public nbrPage: string) {
  }
}
