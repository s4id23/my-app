export class Audio {
  constructor(public id: string,
              public titre: string,
              public auteur: string,
              public genre: string,
              public duree: string,
              ) {
  }
}
