export class Personnes {
  constructor(public id: number,
              public name: string) {
  }
}
