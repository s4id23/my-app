export class These {
  constructor(public id: string,
              public titre: string,
              public auteur: string,
              public genre: string,
              public dateSoutenance: string) {
  }
}
