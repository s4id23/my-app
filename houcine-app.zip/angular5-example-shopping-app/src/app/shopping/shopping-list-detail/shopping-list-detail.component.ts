import {Component} from '@angular/core';
import {Personnes} from '../shared/personnes.model';
import {ShoppingService} from '../shared/shopping.service';
import {ActivatedRoute} from '@angular/router';
import {Product} from '../shared/product.model';
import {Audio} from '../shared/audio.model';
import {These} from '../shared/these.model';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-shopping-list-detail',
  templateUrl: './shopping-list-detail.component.html',
  styleUrls: ['./shopping-list-detail.component.scss']
})
export class ShoppingListDetailComponent {

  personnes: Personnes;
  products: Product[];
  audios: Audio[];
  theses: These[];
  search: string;
  shoppingListProducts: Product[];
  listNameEditMode: boolean;
  editShoppingListNameForm: FormGroup;

  constructor(private shoppingService: ShoppingService, private activatedRoute: ActivatedRoute, private formBuilder: FormBuilder) {
    this.editShoppingListNameForm = this.formBuilder.group({
      'shoppingListName': ['', [Validators.required]]
    });
    this.activatedRoute.params.subscribe((params: any) => {
      if (params['id']) {
        this.personnes = this.shoppingService.getShoppingListById(params['id']);
      } else {
        if (this.shoppingService.isThereShoppingLists()) {
          // if there are any shopping lists - get the first one
          this.personnes = this.shoppingService.getFirstShoppingList();

        } else {
          // if there are no shopping lists
          this.personnes = this.shoppingService.initShoppingListsWithDefault();
        }
      }
      this.shoppingListProducts = this.shoppingService.getProductsByShoppingList(this.personnes);
    });

    this.shoppingService.getProducts().subscribe((products: Array<Product>) => {
      this.products = products;
    });

    this.shoppingService.getAudios().subscribe((audios: Array<Audio>) => {
      this.audios = audios;
    });

    this.shoppingService.getTheses().subscribe((theses: Array<These>) => {
      this.theses = theses;
    });

    this.listNameEditMode = false;
  }

  saveShoppingListName(formData: object) {
    const slName = formData['shoppingListName'];
    this.personnes.name = slName;
    this.shoppingService.updateShoppingList(this.personnes);
    this.shoppingService.showSnackBar('saved');

  }

  editShoppingListName() {
    if (this.listNameEditMode) {
      this.listNameEditMode = false;
    } else {
      this.listNameEditMode = true;
    }
  }

  removeProductFromShoppingList(product: Product) {
    this.shoppingListProducts = this.shoppingListProducts.filter(pr => pr.id !== product.id);
    this.shoppingService.removeProductFromShoppingList(product, this.personnes);
    this.shoppingService.showSnackBar('productRemovedFromShoppingList');

  }

  getProducts() {
    this.shoppingService.getProducts(this.search).subscribe((products: Array<Product>) => {
      this.products = products;
    });
  }

  getTheses() {
    this.shoppingService.getProducts(this.search).subscribe((products: Array<Product>) => {
      this.products = products;
    });
  }

  getAudios() {
    this.shoppingService.getAudios(this.search).subscribe((audios: Array<Audio>) => {
      this.audios = audios;
    });
  }

  addProductToCurrentList(product) {
    this.shoppingService.addProductToShoppingList(product, this.personnes);
    this.shoppingService.showSnackBar('productAdded');
    this.shoppingListProducts.unshift(product);
  }
}
